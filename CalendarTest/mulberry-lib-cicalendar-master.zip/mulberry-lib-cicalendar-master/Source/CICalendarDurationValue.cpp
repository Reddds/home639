/*
	CICalendarDurationValue.cpp

	Author:
	Description:	<describe the CICalendarDurationValue class here>
*/

#include "CICalendarDurationValue.h"


using namespace iCal;
