/*======================================================================
 FILE: icalparam.h
 CREATOR: eric 20 March 1999

 (C) COPYRIGHT 2000, Eric Busboom, http://www.softwarestudio.org

 This program is free software; you can redistribute it and/or modify
 it under the terms of either:

    The LGPL as published by the Free Software Foundation, version
    2.1, available at: http://www.fsf.org/copyleft/lesser.html

 Or:

    The Mozilla Public License Version 1.0. You may obtain a copy of
    the License at http://www.mozilla.org/MPL/

  The original code is icalparam.h
======================================================================*/
#ifndef ICALDERIVEDPARAMETER_H
#define ICALDERIVEDPARAMETER_H

#include "libical_ical_export.h"

typedef struct icalparameter_impl icalparameter;

LIBICAL_ICAL_EXPORT const char* icalparameter_enum_to_string(int e);
LIBICAL_ICAL_EXPORT int icalparameter_string_to_enum(const char* str);

<insert_code_here>
